export type GoalType =
  | "viral_content_batch"
  | "affiliate_site_autopilot"
  | "social_campaign";

export type WorkflowStatus =
  | "pending"
  | "running"
  | "waiting_review"
  | "failed"
  | "completed";

export type ContentStatus = "draft" | "approved" | "scheduled" | "published";

export interface GoalRequest {
  goal: string;
  niche?: string;
  platforms?: string[];
  quantity?: number;
  tone?: string;
  monetization?: string[];
  workspaceId?: string;
}

export interface StructuredGoal {
  goalType: GoalType;
  niche: string;
  platforms: string[];
  quantity: number | null;
  deliverables: string[];
  tone: string | null;
  constraints: string[];
  successMetric: string | null;
}

export interface WorkflowStepDefinition<TInput = unknown> {
  key: string;
  agentName: string;
  input: TInput;
}

export interface WorkflowPlan {
  workflowName: string;
  goalType: GoalType;
  steps: WorkflowStepDefinition[];
}

export interface ContentItemDraft {
  type: string;
  platform?: string;
  title?: string;
  body: string;
  metadata?: Record<string, unknown>;
  status?: ContentStatus;
}

export interface AgentContext {
  userId: string;
  workspaceId: string;
  projectId: string;
  traceId: string;
  modelProvider: "openai" | "anthropic" | "google";
  logger: {
    info: (message: string, meta?: unknown) => void;
    error: (message: string, meta?: unknown) => void;
  };
}

export interface GoalInterpretation extends StructuredGoal {
  projectTitle: string;
}

export interface PlannerInput {
  request: GoalRequest;
  interpretation: GoalInterpretation;
}

export interface HookItem {
  pillar: string;
  hook: string;
}

export interface ScriptItem extends HookItem {
  script: string;
}

export interface CaptionItem extends ScriptItem {
  caption: string;
}

export interface ScheduleItem {
  index: number;
  platform: string;
  publishAtIso: string;
}

export interface WorkflowArtifacts {
  interpretation?: GoalInterpretation;
  plan?: WorkflowPlan;
  pillars?: string[];
  hooks?: HookItem[];
  scripts?: ScriptItem[];
  captions?: CaptionItem[];
  schedule?: ScheduleItem[];
  contentDrafts?: ContentItemDraft[];
  [key: string]: unknown;
}

export interface CreateProjectInput extends GoalRequest {
  title?: string;
}
